# 🏁 K53 Academy — *Master the Road*

A gamified, cyberpunk-styled learning platform that turns the South African
**Learner's & Driver's Licence** syllabus into rooms, paths, XP, streaks and
leaderboards. Think *TryHackMe, but for K53* — covering all three vehicle codes:

- **Code 1** (A1/A) — Motorcycles
- **Code 2** (B) — Light motor vehicles
- **Code 3** (C1/C/EC) — Heavy motor vehicles

> **This is a demo-first build.** The entire experience runs locally with **no
> backend, no accounts, no API keys** — content lives in `lib/data/*` and your
> progress persists to `localStorage`. Supabase, Prisma/Postgres and Paystack
> are scaffolded as clean integration points, ready to switch on (see
> [Going to production](#-going-to-production)).

---

## ⚡ Quick start

```bash
npm install
npm run dev
# open http://localhost:5300
```

That's it — no `.env` required for the demo. Start at `/` (landing) → `/onboarding`
→ `/dashboard`.

---

## ✨ What's built

| Area | Status | Where |
| --- | --- | --- |
| **Design system** (dark neon theme, tokens, motion) | ✅ | `tailwind.config.ts`, `app/globals.css`, `components/ui/*` |
| **Dashboard** (level ring, XP bar, streak, charts, badges) | ✅ | `app/(dashboard)/dashboard` |
| **Learning Paths** (6 guided journeys) | ✅ | `app/(dashboard)/paths`, `lib/data/paths.ts` |
| **Rooms** (intro → material → quiz → XP) | ✅ | `app/(dashboard)/rooms/[slug]`, `lib/data/rooms.ts` |
| **Question engine** (MCQ, true/false, image, scenario) | ✅ | `components/quiz/quiz-engine.tsx` |
| **Road Signs trainer** (library, flashcards, Sign Rush) | ✅ | `app/(dashboard)/signs`, `components/signs/road-sign.tsx` |
| **Mock test** (official structure, timer, section pass marks) | ✅ | `app/(dashboard)/mock-test` |
| **Gamification** (XP/levels, ranks, badges, streaks, coins) | ✅ | `lib/xp-engine.ts`, `lib/store.ts`, `components/gamification/*` |
| **Spaced repetition** (SM-2 weak-area surfacing) | ✅ | `lib/spaced-repetition.ts` |
| **Leaderboard** (global / provincial / friends) | ✅ | `app/(dashboard)/leaderboard` |
| **Profile + Monetization** (plans, streak freezes, settings) | ✅ | `app/(dashboard)/profile`, `lib/paystack.ts` |
| **Admin panel** (analytics, content, add-question) | ✅ | `app/admin` |
| **Accounts + sign-in** (email/password or guest, route guard) | ✅ | `lib/auth-store.ts`, `app/(auth)/sign-in`, `sign-up`, `components/auth/guard.tsx` |
| **Per-user progress persistence** (survives page close, isolated per account) | ✅ | `lib/store.ts` (`loadProgressForUser`) |
| **Light / Dark theme** (persisted toggle, no flash, default dark) | ✅ | `components/theme.tsx`, `app/globals.css` (CSS vars) |
| **AI assistant "Robo-Instructor"** (answers from app content; optional Claude) | ✅ | `components/assistant/*`, `lib/assistant/knowledge.ts`, `app/api/chat/route.ts` |
| **Loading screen, +XP toasts, level-up confetti** | ✅ | `components/loading-screen.tsx`, `components/gamification/*`, `components/effects/confetti.tsx` |
| **Onboarding** (license → code → province → profile) | ✅ | `app/(auth)/onboarding` |
| **PWA manifest + app icon** | ✅ | `public/manifest.json`, `app/icon.svg` |
| **Prisma schema** (all required models) | ✅ | `prisma/schema.prisma` |
| Supabase (cloud) auth · Paystack checkout · offline SW · full i18n | 🔌 stubbed | see below |

### Accounts & the AI assistant
- **Accounts are local (device-scoped) by default** — sign up with email + password (or continue as a guest) and your XP, streaks, badges and history persist to `localStorage` per account, surviving page close. For real cross-device accounts, swap `lib/auth-store.ts` for Supabase Auth (already stubbed in `lib/auth.ts`).
- **Robo-Instructor** answers from the app's own K53 content with zero setup (client-side retrieval in `lib/assistant/knowledge.ts`). If you set `ANTHROPIC_API_KEY`, `app/api/chat/route.ts` upgrades it to **Claude (`claude-opus-4-8`)**, grounded in the same content; without a key it silently uses the local engine.

### The road signs are code, not images
Every SA road sign is drawn programmatically from a declarative spec
(`lib/data/signs.ts` → `components/signs/road-sign.tsx`) following **SARTSM**
shape & colour conventions. No image assets, infinitely themeable, and they
scale crisply anywhere.

---

## 🎨 Design language

- **Theme** — a bright **traffic-light / road-sign** look: warm-white paper
  surfaces `#FBF6EE`, traffic **red** primary `#E4002B`, warning **yellow/gold**
  `#E68A00`/`#FFC21A`, "go" **green** `#0B9C56`, and dark **asphalt** `#1B1C21`
  for text, borders and contrast bands. Road-marking dividers + a traffic-light
  motif ([components/brand/traffic-light.tsx](components/brand/traffic-light.tsx)).
- **Type** — Geist Sans (UI), Space Grotesk (headings), JetBrains Mono (stats).
- **Motion** — Framer Motion page slides, ticking XP counters, badge-unlock
  particle bursts, animated road-line + grid backdrops.
- **Token note** — legacy Tailwind token names were kept and remapped to the new
  palette (`cyan`→red, `amber`→yellow, `grass`→green, `navy`→light paper, `ink`→
  dark text) plus a new `asphalt` scale — see the header comment in
  [tailwind.config.ts](tailwind.config.ts).

---

## 🕹️ The dopamine loop

Every action earns XP → XP fills the level ring → levels unlock **ranks**
(Pedestrian → Learner → … → K53 Master) and **badges** (which pop with a
particle burst). Daily check-ins build a **streak** (protected by purchasable
freezes); wrong answers feed the **SM-2** schedule and resurface in **Weak
Areas**. It's designed to be genuinely addictive.

---

## 🗂️ Project structure

```
k53-academy/
├── app/
│   ├── (auth)/onboarding/       # multi-step profile setup
│   ├── (dashboard)/             # app shell + all authed pages
│   │   ├── dashboard/  paths/  rooms/[slug]/
│   │   ├── practice/  signs/  mock-test/
│   │   ├── leaderboard/  profile/
│   ├── admin/                   # content + analytics
│   └── page.tsx                 # marketing landing
├── components/  (ui · gamification · quiz · signs · rooms · layout · brand)
├── lib/
│   ├── store.ts                 # Zustand + localStorage (demo "backend")
│   ├── xp-engine.ts  spaced-repetition.ts  achievements.ts
│   ├── db.ts  auth.ts  paystack.ts   # integration stubs
│   └── data/                    # paths · rooms · questions · signs · badges
├── prisma/schema.prisma  seed.ts
└── public/  (manifest.json · icon.svg)
```

---

## 🚀 Going to production

Do these in order — each is isolated behind a stub so the app keeps running.

1. **Supabase** — create a project, set `NEXT_PUBLIC_SUPABASE_*`, install
   `@supabase/supabase-js @supabase/ssr`, then finish `lib/auth.ts` and add
   middleware to guard `app/(dashboard)`.
2. **Database** — set `DATABASE_URL`/`DIRECT_URL`, `npm i -D prisma`,
   `npm i @prisma/client`, `npx prisma migrate dev`, then `npx tsx prisma/seed.ts`.
   Uncomment the client in `lib/db.ts` and move the Zustand writes into API routes.
3. **Paystack** — set the keys, implement `initTransaction` in `lib/paystack.ts`
   and a verify callback route. Currency ZAR; supports cards, EFT, SnapScan.
4. **Offline PWA** — add a service worker (e.g. `next-pwa`) to cache downloaded
   rooms — a big win for SA data costs.
5. **i18n** — the language toggle is in `profile`; wire `next-intl` for full
   English / isiZulu / Afrikaans / Sesotho.

### Deploy (Vercel + Supabase)
Push to GitHub → import into Vercel → add the env vars from `.env.example` →
deploy. Point Supabase's connection strings at your project and run migrations
from CI or locally against the production DB.

---

## 📚 Content & licensing

Learning material is **original text** teaching the same concepts as the
official **K53 / SARTSM** framework (Dept. of Transport / RTMC) — nothing is
copied verbatim, and no third-party K53 app content is used. Road signs follow
published government SARTSM standards. Partner logos (RTMC, AA South Africa,
Arrive Alive) are shown only as *pending* placeholders and require official
approval before display.

## 🔑 Demo "admin"
The admin panel is open at `/admin` in the demo (no auth). In production, gate it
behind a Supabase role check. Suggested test credentials to create:
`admin@k53academy.co.za` with an `admin` role claim.

---

Built with Next.js 14 · TypeScript · Tailwind · Framer Motion · Zustand · Recharts.
**Master the Road. 🚦**
